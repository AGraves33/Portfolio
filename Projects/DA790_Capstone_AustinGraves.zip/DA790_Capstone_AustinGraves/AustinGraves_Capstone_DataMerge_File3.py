''' Austin Graves DA 790 Capstone #3
    This code will analyze the newly obtained data from 1993-1999 and format
    it in a way that will allow us to combine it with the 'complete.xlsx' file
    that was created in the data prep python file.
'''
import pandas as pd
# Create function to split the team name based on the amount of words
def NameSplit(team):
    # Change the Oilers to Titans to match our dataset
    if team == 'Houston Oilers':
        team = 'Tennessee Titans'
    fullName = team.split()
    if len(fullName) == 2:
        city = fullName[0]
        name = fullName[1]
    else:
        city = ' '.join(fullName[:2])
        name = fullName[2]
    return city, name
# Function to determine who won the game and to create a new columnn for it
def PointCheck(data):
    if data['points_for'] > data['points_allowed']:
        return data['Home_team']
    else:
        return data['opp']
    
# Load Datasets
newData_df = pd.read_excel('ExtraGameData.xlsx')
complete_df = pd.read_csv('complete.csv')

# Create columns that have the city and name seperated
newData_df[['home_team_city','home_team_name']] = newData_df['Home_team'].apply(lambda x: pd.Series(NameSplit(x)))
newData_df[['away_team_city','away_team_name']] = newData_df['opp'].apply(lambda x: pd.Series(NameSplit(x)))

# Create winner column and winner_binary column
newData_df['winner'] = newData_df.apply(PointCheck, axis=1)
newData_df['winner_binary'] = newData_df.apply(lambda row: 1 if row['home_team_city'] + ' ' + row['home_team_name'] == row['winner'] else 0, axis=1)

# Create Point Differential Column
newData_df['point_differential'] = abs(newData_df['points_for']-newData_df['points_allowed'])

# Rename Columns
newData_df = newData_df.rename(columns={'points_for':'pts_home','points_allowed':'pts_away','tot_yds':'yds_home','opp_tot_yds':'yds_away'})

# Drop unwanted columns
newData_df = newData_df.drop(['day','rest_days','home_game','distance_travelled','result','pass_yds','rush_yds','opp_pass_yds','opp_rush_yds','opp','Home_team'],axis=1)

attendanceList = []
# Loop through the datasets in folder to create a combined dataframe with all attendance
for i in list(range(1993,2000)):
    if i != 1997:
        attendance_df = pd.read_excel(f'1993-1999-Attendance/{i}.xlsx')
        # Reshape attendance dataframes to match format
        attendance_df = attendance_df.melt(id_vars=['Tm'], var_name='week', value_name='weekly_attendance')
        # Remove Bye Weeks since they are not relevant
        attendance_df = attendance_df[attendance_df['weekly_attendance']!='Bye']
        # Remove 'week' that comes before the numerical value
        attendance_df['week'] = attendance_df['week'].str.replace('Week', '').str.strip().astype(int)
        # Add home_team_name column for when we merge data frames later
        attendance_df[['home_team_city','home_team_name']] = attendance_df['Tm'].apply(lambda x: pd.Series(NameSplit(x)))
        attendance_df = attendance_df.drop(['Tm'],axis=1)
        # Add year to dataframe
        attendance_df['year'] = i
        attendanceList.append(attendance_df)
        attendance_df = pd.DataFrame()

# Write combined data to a new excel file and save it
combinedAttendance_df = pd.concat(attendanceList,ignore_index=True)
excelWriter = pd.ExcelWriter('1993-1999Attendance.xlsx', engine='xlsxwriter')
combinedAttendance_df.to_excel(excelWriter,sheet_name='1993-1999',index=False)
excelWriter.close()

# Merge 1993-1999Attendance.xlsx file with our newData_df
attendance = pd.read_excel('1993-1999Attendance.xlsx')
merged_df = pd.merge(newData_df,attendance, left_on=['year', 'week', 'home_team_name','home_team_city'], right_on=['year', 'week', 'home_team_name','home_team_city'], how='inner')

# Merge the above data frame with the extra stadium capacity excel file to get the stadium capacities
capacity = pd.read_excel('ExtraStadiumData.xlsx')
merged2_df = pd.merge(merged_df,capacity,left_on=['year','home_team_name'], right_on=['year', 'home_team_name'], how='inner')
# Calculate Stadium filled %
merged2_df['stadium_filled'] = round((merged2_df['weekly_attendance']/merged2_df['capacity'])*100,2)

# Reorder columns for readability
merged2_df = merged2_df.iloc[:, [5,0,6,7,8,9,10,11,13,14,17,1,2,12,3,4,15,16]]

# Merge the new dataframe with the previous complete dataframe to get our final dataframe
FinalDataSet = pd.concat([merged2_df,complete_df],ignore_index=True)
FinalDataSet.to_csv('FinalDataSet.csv', index=False)
