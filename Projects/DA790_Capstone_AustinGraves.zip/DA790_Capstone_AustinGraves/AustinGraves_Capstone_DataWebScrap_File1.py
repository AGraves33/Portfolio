''' Austin Graves DA 790 Capstone #1
    This program downloads extra data from the pro football reference website using a python library.
    The program exports an excel file titled ExtraGameData.xlsx that contains game data from
    1993-1999 that will be added to my analysis. The attendance and certain game
    statistics is added in the DataMerge file as this is not scraped with the api.
'''
import pandas as pd
import time
from pro_football_reference_web_scraper import team_game_log as team

# Create list of every team
teams =  ['Tennessee Titans','Baltimore Ravens','Pittsburgh Steelers','Jacksonville Jaguars','Cincinnati Bengals','Cleveland Browns',
             'Miami Dolphins','Indianapolis Colts','New York Jets','Buffalo Bills','New England Patriots',
            'Oakland Raiders','Denver Broncos','Kansas City Chiefs','Seattle Seahawks','Los Angeles Chargers',
             'Minnesota Vikings','Tampa Bay Buccaneers','Green Bay Packers','Detroit Lions','Chicago Bears',
             'New Orleans Saints','Los Angeles Rams','Carolina Panthers','San Francisco 49ers','Atlanta Falcons',
            'New York Giants','Philadelphia Eagles','Washington Redskins','Dallas Cowboys','Arizona Cardinals',]
dfList = []
years = [1993]
columns = ['week','day','rest_days','home_team','distance_travelled','opp', 'result','points_for','points_allowed','tot_yds','pass_yds','rush_yds','opp_tot_yds','opp_pass_yds','opp_rush_yds']
# Look through the years and teams to download the data
for i in list(range(1993,2000)):
    for j in teams:
        # Create a delay to avoid the rate limit
        time.sleep(8)
        # There is an issue with the web scraping library that prevents 1997 from downloading data except for 2 teams, so we will skip this year
        if i == 1997:
            pass
        try:
            # Attempt to download the team data. If the team didn't exist, this fails and goes to the next team
            game_log = team.get_team_game_log(team = j, season = i)
            df = pd.DataFrame(game_log,columns=columns)
            df['Home_team'] = j
            df['year'] = i
            df = df.rename(columns={'home_team': 'home_game'})
            df = df[df['home_game']==True]
            dfList.append(df)
            df = pd.DataFrame()
            # If the team fails to download, it skips it
        except:
            pass
# Combine the dataframes vertically using concat
stacked = pd.concat(dfList,ignore_index=True)
# Create excel writer and file name
excelWriter = pd.ExcelWriter('ExtraGameData.xlsx', engine='xlsxwriter')
stacked.to_excel(excelWriter,sheet_name='1993-1999',index=False)
excelWriter.close()
