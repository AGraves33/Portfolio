''' Austin Graves DA 790 Capstone #2
    This program reads 3 excel files containing the weekly results of each team at home,
    the attendance for each home game, and the yearly results of each team. It then exports a new
    excel file containing the merged data from these excel files, reads that file in and merges
    the data once more to create an excel file containing the weekly results of every team, and
    the overall season result as seperate collumns attached. It is called "complete.csv".
    This file will be used for future analysis as it contians the attendance, weekly home performance,
    and the overall season result. This is only for the 2000-2019 season data files
'''
import pandas as pd
import numpy as np

# Load Datasets
attendance_df = pd.read_csv('attendance.csv')
games_df = pd.read_csv('games.csv')
standings_df = pd.read_csv('standings.csv')

# Remove Null values from attendance, these are when a team did not play (Bye week). Drop unwanted columns
attendance_df = attendance_df.dropna()
attendance_df = attendance_df.drop(['total','home','away','team'],axis=1)
attendance_df.reset_index(inplace=True,drop=True)

# Remove unwanted columns
games_df = games_df.drop(['tie','day','date','time','home_team','away_team'],axis = 1)

# Remove playoff games and superbowl (Will only look at regular season)
playoffs = ['WildCard','Division','ConfChamp','SuperBowl']
for i in playoffs:
    games_df = games_df.drop(games_df[games_df['week'] == i].index)
    
# Change week to int64
games_df['week'] = games_df['week'].astype('int64')
games_df.reset_index(inplace=True,drop = True)

# Merge Attendance and games data frames
weekly_df = pd.merge(attendance_df,games_df, left_on=['year', 'week', 'team_name'], right_on=['year', 'week', 'home_team_name'], how='inner')

# Drop column after join since it is the same as the home team name
weekly_df = weekly_df.drop('team_name',axis=1)

# Create Point differential column
weekly_df['point_differential'] = weekly_df['pts_win']-weekly_df['pts_loss']

# Create proportion of stadium capacity filled column
weekly_df['stadium_filled'] = round((weekly_df['weekly_attendance']/weekly_df['capacity'])*100,2)

# Create new column with binary result for winner
weekly_df['winner_binary'] = weekly_df.apply(lambda row: 1 if row['home_team_city'] + ' ' + row['home_team_name'] == row['winner'] else 0, axis=1)

# Reorder columns for readability
weekly_df = weekly_df.iloc[:, [0,1,11,10,13,12,3,17,2,14,16,4,5,15,6,7,8,9]]

# Export to CSV
weekly_df.to_csv('season_weekly.csv', index=False)

# Import New Excel as season weekly dataframe
sw_df = pd.read_csv('season_weekly.csv')

# Add Season Statistics to each team for future analysis
complete_df = pd.merge(sw_df, standings_df, left_on=['home_team_name','year'],right_on=['team_name','year'],how='left')

# Rename Columns
complete_df = complete_df.rename(columns={'wins':'season_wins','loss':'season_loss'})

# Remove columns for readability
complete_df = complete_df.drop(['team','team_name'],axis = 1)

# Change values for playoofs and sb_winner to make it numerical
complete_df['playoffs'] = complete_df['playoffs'].replace('No Playoffs',0).replace('Playoffs',1)
complete_df['sb_winner'] = complete_df['sb_winner'].replace('No Superbowl',0).replace('Won Superbowl',1)

# Rename columns from pts_win, yds_win, etc. to be for the home and away team
complete_df.rename(columns={'pts_win':'pts_home','pts_loss':'pts_away','yds_win':'yds_home','yds_loss':'yds_away','turnovers_win':'turnovers_home','turnovers_loss':'turnovers_away'},inplace=True)

# Unpack the values and switch them based on if the home team won the game or not. Ex: If home team lost, pts_home will have old pts_loss value. 
complete_df['pts_home'], complete_df['pts_away'] = zip(*complete_df.apply(lambda row: (row['pts_home'], row['pts_away']) if row['winner_binary'] == 1 else (row['pts_away'], row['pts_home']), axis=1))
complete_df['yds_home'], complete_df['yds_away'] = zip(*complete_df.apply(lambda row: (row['yds_home'], row['yds_away']) if row['winner_binary'] == 1 else (row['yds_away'], row['yds_home']), axis=1))
complete_df['turnovers_home'], complete_df['turnovers_away'] = zip(*complete_df.apply(lambda row: (row['turnovers_home'], row['turnovers_away']) if row['winner_binary'] == 1 else (row['turnovers_away'], row['turnovers_home']), axis=1))

# Drop More Unwanted Columns
complete_df = complete_df.drop(['points_for','points_against','points_differential','margin_of_victory','strength_of_schedule','simple_rating','offensive_ranking','defensive_ranking','playoffs','sb_winner','turnovers_home','turnovers_away'],axis=1)
# Export Final Dataframe as excel file
complete_df.to_csv('complete.csv', index=False)



    